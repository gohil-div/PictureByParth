import { createFileRoute, Link } from "@tanstack/react-router";
import { images } from "@/lib/stories";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Maison Aurelia — Stories Worth Remembering" },
      {
        name: "description",
        content:
          "A luxury editorial wedding photography studio. We do not photograph weddings — we publish stories worth remembering.",
      },
      { property: "og:title", content: "Maison Aurelia — Stories Worth Remembering" },
      {
        property: "og:description",
        content: "A luxury editorial wedding photography studio.",
      },
    ],
  }),
  component: Landing,
});

type Tile = {
  src: string;
  alt: string;
  className: string;
  delay: string;
  floatDelay: string;
};

const tiles: Tile[] = [
  {
    src: images.hero1,
    alt: "Bride in a stone chapel",
    className:
      "absolute left-[3%] top-[8%] w-[22vw] max-w-[280px] aspect-[3/4] hidden md:block",
    delay: "0.1s",
    floatDelay: "0s",
  },
  {
    src: images.bouquet,
    alt: "Bridal bouquet",
    className:
      "absolute left-[10%] bottom-[6%] w-[18vw] max-w-[220px] aspect-[4/5] hidden md:block",
    delay: "0.6s",
    floatDelay: "1.4s",
  },
  {
    src: images.bride1,
    alt: "Bride on a marble staircase",
    className:
      "absolute right-[4%] top-[6%] w-[20vw] max-w-[260px] aspect-[3/4] hidden md:block",
    delay: "0.3s",
    floatDelay: "2.2s",
  },
  {
    src: images.reception,
    alt: "Candlelit reception",
    className:
      "absolute right-[8%] bottom-[10%] w-[26vw] max-w-[340px] aspect-[16/10] hidden md:block",
    delay: "0.8s",
    floatDelay: "0.7s",
  },
  {
    src: images.detail1,
    alt: "Hands and rings",
    className:
      "absolute left-[36%] top-[4%] w-[14vw] max-w-[170px] aspect-[4/5] hidden lg:block",
    delay: "0.45s",
    floatDelay: "3s",
  },
  {
    src: images.ceremony,
    alt: "Cliffside ceremony",
    className:
      "absolute right-[34%] bottom-[4%] w-[16vw] max-w-[200px] aspect-[16/10] hidden lg:block",
    delay: "0.95s",
    floatDelay: "1.8s",
  },
  // Mobile tiles
  {
    src: images.hero1,
    alt: "",
    className: "absolute left-[-6%] top-[6%] w-[42vw] aspect-[3/4] md:hidden",
    delay: "0.1s",
    floatDelay: "0s",
  },
  {
    src: images.bouquet,
    alt: "",
    className: "absolute right-[-4%] top-[12%] w-[36vw] aspect-[4/5] md:hidden",
    delay: "0.4s",
    floatDelay: "1.2s",
  },
  {
    src: images.bride1,
    alt: "",
    className: "absolute left-[4%] bottom-[8%] w-[36vw] aspect-[3/4] md:hidden",
    delay: "0.6s",
    floatDelay: "2s",
  },
  {
    src: images.reception,
    alt: "",
    className: "absolute right-[2%] bottom-[6%] w-[44vw] aspect-[16/10] md:hidden",
    delay: "0.85s",
    floatDelay: "0.6s",
  },
];

function Landing() {
  return (
    <main className="relative min-h-screen w-full overflow-hidden bg-ivory text-charcoal">
      {/* Living collage */}
      <div className="absolute inset-0">
        {tiles.map((t, i) => (
          <div
            key={i}
            className={`${t.className} animate-collage-float`}
            style={{ animationDelay: t.floatDelay }}
          >
            <div
              className="h-full w-full overflow-hidden animate-mask-reveal shadow-[0_30px_80px_-40px_rgba(28,28,28,0.35)]"
              style={{ animationDelay: t.delay }}
            >
              <img
                src={t.src}
                alt={t.alt}
                className="h-full w-full object-cover animate-ken-burns"
                loading={i < 2 ? "eager" : "lazy"}
              />
            </div>
          </div>
        ))}
        {/* warm vignette */}
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_30%,var(--ivory)_85%)]" />
      </div>

      {/* Centerpiece */}
      <div className="relative z-10 flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <div className="animate-reveal-fade" style={{ animationDelay: "0.4s" }}>
          <p className="editorial-eyebrow">Maison Aurelia · Est. MMXII</p>
        </div>

        <h1
          className="serif-display mt-10 text-[clamp(3rem,9vw,8.5rem)] animate-reveal-up"
          style={{ animationDelay: "0.7s" }}
        >
          Stories <span className="serif-display-roman not-italic">Worth</span>
          <br />
          Remembering
        </h1>

        <div
          className="mt-8 flex items-center gap-4 animate-reveal-fade"
          style={{ animationDelay: "1.2s" }}
        >
          <span className="editorial-rule" />
          <p className="text-xs uppercase tracking-[0.32em] text-charcoal-soft">
            A Wedding Journal
          </p>
          <span className="editorial-rule" />
        </div>

        <div className="mt-16 animate-reveal-up" style={{ animationDelay: "1.5s" }}>
          <Link
            to="/journal"
            className="group inline-flex items-center gap-5 border border-charcoal/30 px-9 py-5 text-[0.7rem] uppercase tracking-[0.32em] text-charcoal transition-all duration-700 hover:border-charcoal hover:bg-charcoal hover:text-ivory"
          >
            <span>Enter the Journal</span>
            <span className="h-px w-10 bg-current transition-all duration-700 group-hover:w-16" />
          </Link>
        </div>

        <p
          className="absolute bottom-8 text-[0.65rem] uppercase tracking-[0.32em] text-charcoal-soft animate-reveal-fade"
          style={{ animationDelay: "1.8s" }}
        >
          Vol. XIV · Selected Works
        </p>
      </div>
    </main>
  );
}
