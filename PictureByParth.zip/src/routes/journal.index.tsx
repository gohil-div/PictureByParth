import { createFileRoute, Link } from "@tanstack/react-router";
import { stories, chapters, images } from "@/lib/stories";

export const Route = createFileRoute("/journal/")({
  head: () => ({
    meta: [
      { title: "The Journal — Maison Aurelia" },
      {
        name: "description",
        content:
          "Featured wedding stories, chapters, and selected moments from Maison Aurelia — a luxury editorial wedding studio.",
      },
      { property: "og:title", content: "The Journal — Maison Aurelia" },
      { property: "og:image", content: images.hero2 },
    ],
  }),
  component: Journal,
});

function Journal() {
  const featured = stories.slice(0, 3);

  return (
    <>
      {/* SECTION 1 — Hero Story */}
      <section className="relative h-[100svh] w-full overflow-hidden">
        <img
          src={images.hero2}
          alt="Bride and groom in a Tuscan olive grove at sunrise"
          className="absolute inset-0 h-full w-full object-cover animate-ken-burns"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal/40 via-transparent to-charcoal/60" />

        <div className="relative z-10 flex h-full flex-col justify-between px-6 py-32 md:px-16 md:py-36">
          <div className="animate-reveal-fade" style={{ animationDelay: "0.6s" }}>
            <p className="text-[0.7rem] uppercase tracking-[0.32em] text-ivory/80">
              Volume XIV · The Quiet Issue
            </p>
          </div>

          <div className="max-w-3xl animate-reveal-up" style={{ animationDelay: "0.9s" }}>
            <h1 className="serif-display text-[clamp(3rem,8vw,7.5rem)] text-ivory">
              We do not <span className="not-italic">photograph</span> weddings.
              <br />
              We publish <em>them.</em>
            </h1>
            <div className="mt-10 flex items-center gap-4">
              <span className="h-px w-12 bg-ivory" />
              <p className="text-[0.7rem] uppercase tracking-[0.32em] text-ivory">
                Editorial Wedding Studio · Italy · Worldwide
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2 — Featured Stories */}
      <section className="px-6 py-32 md:px-12 md:py-48">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col items-start justify-between gap-8 md:flex-row md:items-end">
            <div>
              <p className="editorial-eyebrow">§ I · Featured Stories</p>
              <h2 className="serif-display mt-6 text-5xl md:text-7xl">
                The Cover Stories.
              </h2>
            </div>
            <p className="max-w-sm text-sm leading-relaxed text-charcoal-soft">
              Three weddings, three places, three private worlds. Each one
              composed slowly, the way a magazine is composed — never the way a
              gallery is filled.
            </p>
          </div>

          <div className="mt-20 grid gap-x-10 gap-y-32 md:grid-cols-12">
            {featured.map((s, i) => {
              // asymmetric placement
              const placement = [
                "md:col-span-7 md:col-start-1",
                "md:col-span-6 md:col-start-7 md:mt-32",
                "md:col-span-7 md:col-start-3",
              ][i];
              return (
                <article key={s.slug} className={placement}>
                  <Link
                    to="/journal/stories/$slug"
                    params={{ slug: s.slug }}
                    className="group block"
                  >
                    <div className="hover-zoom aspect-[4/5] w-full bg-ivory-deep">
                      <img
                        src={s.cover}
                        alt={s.coverAlt}
                        className="h-full w-full object-cover"
                        loading="lazy"
                      />
                    </div>
                    <div className="mt-8 flex items-start justify-between gap-6">
                      <div>
                        <p className="text-[0.65rem] uppercase tracking-[0.32em] text-gold">
                          Chapter · {s.chapter}
                        </p>
                        <h3 className="serif-display mt-3 text-4xl md:text-5xl">
                          {s.couple}
                        </h3>
                        <p className="mt-3 text-sm text-charcoal-soft">
                          {s.location} · {s.date} {s.year}
                        </p>
                      </div>
                      <span className="mt-3 hidden text-[0.65rem] uppercase tracking-[0.32em] text-charcoal link-underline md:inline-block">
                        View Story
                      </span>
                    </div>
                  </Link>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* SECTION 3 — Chapters */}
      <section id="chapters" className="bg-charcoal text-ivory">
        <div className="px-6 py-32 md:px-12 md:py-48">
          <div className="mx-auto max-w-7xl">
            <div className="flex flex-col items-start justify-between gap-8 md:flex-row md:items-end">
              <div>
                <p className="editorial-eyebrow !text-gold-soft">§ II · The Archive</p>
                <h2 className="serif-display mt-6 text-5xl md:text-7xl text-ivory">
                  Enter a Chapter.
                </h2>
              </div>
              <p className="max-w-sm text-sm leading-relaxed text-ivory/70">
                The archive is not sorted by year or by venue. It is sorted by
                feeling — by the kind of memory you have come looking for.
              </p>
            </div>

            <div className="mt-20 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {chapters.map((c, i) => (
                <a
                  key={c.name}
                  href={`#chapter-${c.name.toLowerCase()}`}
                  className="group relative block aspect-[3/4] overflow-hidden"
                  style={{ marginTop: i % 2 === 1 ? "3rem" : "0" }}
                >
                  <img
                    src={c.image}
                    alt=""
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-charcoal/20 via-charcoal/30 to-charcoal/80 transition-opacity duration-700 group-hover:from-charcoal/10 group-hover:to-charcoal/70" />
                  <div className="absolute inset-x-0 bottom-0 p-8">
                    <p className="text-[0.65rem] uppercase tracking-[0.32em] text-gold-soft">
                      Chapter {String(i + 1).padStart(2, "0")}
                    </p>
                    <h3 className="serif-display mt-4 text-5xl text-ivory">
                      {c.name}
                    </h3>
                    <p className="mt-3 text-sm italic text-ivory/80">{c.tagline}</p>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4 — Selected Moments (mosaic) */}
      <section id="moments" className="px-6 py-32 md:px-12 md:py-48">
        <div className="mx-auto max-w-7xl">
          <div className="mb-20 max-w-2xl">
            <p className="editorial-eyebrow">§ III · Selected Moments</p>
            <h2 className="serif-display mt-6 text-5xl md:text-7xl">
              Fragments, <em>arranged.</em>
            </h2>
            <p className="mt-6 text-sm leading-relaxed text-charcoal-soft">
              A composition — not a grid. The hand of a bride. A lit candle.
              The last dance. Pieces of mornings and evenings that, placed
              beside one another, begin to feel like a life.
            </p>
          </div>

          {/* Magazine mosaic */}
          <div className="grid grid-cols-12 gap-4 md:gap-6">
            <figure className="col-span-12 md:col-span-7">
              <div className="hover-zoom aspect-[16/10]">
                <img src={images.reception} alt="Candlelit dinner under olive trees" className="h-full w-full object-cover" loading="lazy" />
              </div>
            </figure>
            <figure className="col-span-7 md:col-span-3 md:mt-24">
              <div className="hover-zoom aspect-[3/4]">
                <img src={images.detail1} alt="Bride's hands and ring" className="h-full w-full object-cover" loading="lazy" />
              </div>
              <figcaption className="mt-3 text-[0.65rem] uppercase tracking-[0.32em] text-charcoal-soft">
                Plate I · A still hand
              </figcaption>
            </figure>
            <figure className="col-span-5 md:col-span-2">
              <div className="hover-zoom aspect-[4/5]">
                <img src={images.bouquet} alt="Bridal bouquet" className="h-full w-full object-cover" loading="lazy" />
              </div>
            </figure>

            <div className="col-span-12 md:col-span-4 md:col-start-2 md:py-16">
              <p className="serif-display text-3xl md:text-4xl italic leading-snug">
                "Some memories deserve to live forever."
              </p>
              <p className="mt-6 text-[0.65rem] uppercase tracking-[0.32em] text-gold">
                Editor's Note · Vol. XIV
              </p>
            </div>
            <figure className="col-span-12 md:col-span-6">
              <div className="hover-zoom aspect-[4/3]">
                <img src={images.dance} alt="First dance" className="h-full w-full object-cover" loading="lazy" />
              </div>
            </figure>

            <figure className="col-span-6 md:col-span-5 md:col-start-2">
              <div className="hover-zoom aspect-[3/4]">
                <img src={images.bride1} alt="Bride on a staircase" className="h-full w-full object-cover" loading="lazy" />
              </div>
            </figure>
            <figure className="col-span-6 md:col-span-5 md:mt-32">
              <div className="hover-zoom aspect-[4/3]">
                <img src={images.ceremony} alt="Cliffside ceremony" className="h-full w-full object-cover" loading="lazy" />
              </div>
              <figcaption className="mt-3 text-[0.65rem] uppercase tracking-[0.32em] text-charcoal-soft">
                Plate VII · The sea, witness
              </figcaption>
            </figure>
          </div>
        </div>
      </section>

      {/* SECTION 5 — Testimonials */}
      <section className="border-y border-charcoal/10 bg-ivory-deep px-6 py-32 md:px-12 md:py-48">
        <div className="mx-auto max-w-5xl text-center">
          <p className="editorial-eyebrow">§ IV · In Their Words</p>
          <blockquote className="serif-display mt-12 text-3xl leading-tight md:text-6xl">
            "They did not document our wedding. They composed it.
            <span className="not-italic"> Years later</span>, we still open the
            book together — and the room goes quiet."
          </blockquote>
          <div className="mt-12 flex items-center justify-center gap-4">
            <span className="editorial-rule" />
            <p className="text-[0.65rem] uppercase tracking-[0.32em] text-charcoal-soft">
              Amelia & Thomas · Tuscany, MMXXV
            </p>
            <span className="editorial-rule" />
          </div>

          <div className="mt-20 grid gap-12 md:grid-cols-3 text-left">
            {[
              {
                q: "An heirloom, not a gallery.",
                a: "Isabel & Rafael · Amalfi",
              },
              {
                q: "A day held in two careful hands.",
                a: "Claire & Henry · Cotswolds",
              },
              {
                q: "The most patient artists we have ever met.",
                a: "Sophia & Lior · Mallorca",
              },
            ].map((t) => (
              <div key={t.a}>
                <p className="serif-display text-2xl italic leading-snug">"{t.q}"</p>
                <p className="mt-4 text-[0.65rem] uppercase tracking-[0.32em] text-charcoal-soft">
                  {t.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 6 — Final CTA */}
      <section id="contact" className="relative h-[100svh] w-full overflow-hidden">
        <img
          src={images.ceremony}
          alt="A ceremony at golden hour above the Mediterranean"
          className="absolute inset-0 h-full w-full object-cover animate-ken-burns"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/30 to-charcoal/40" />
        <div className="relative z-10 flex h-full flex-col items-center justify-center px-6 text-center">
          <p className="editorial-eyebrow !text-gold-soft">§ V · An Invitation</p>
          <h2 className="serif-display mt-8 text-[clamp(3rem,8vw,7.5rem)] text-ivory">
            Let's tell <em>your</em> story.
          </h2>
          <p className="mt-8 max-w-xl text-base leading-relaxed text-ivory/85">
            We accept a small number of weddings each year, by personal
            conversation. Begin with a quiet message — we will write back the
            same day.
          </p>
          <div className="mt-14 flex flex-col items-center gap-5 sm:flex-row">
            <a
              href="mailto:studio@maisonaurelia.com"
              className="group inline-flex items-center gap-5 border border-ivory/40 bg-ivory/5 px-9 py-5 text-[0.7rem] uppercase tracking-[0.32em] text-ivory backdrop-blur-sm transition-all duration-700 hover:border-ivory hover:bg-ivory hover:text-charcoal"
            >
              <span>Book a Consultation</span>
              <span className="h-px w-10 bg-current transition-all duration-700 group-hover:w-16" />
            </a>
            <a
              href="https://wa.me/000000000"
              className="text-[0.7rem] uppercase tracking-[0.32em] text-ivory link-underline"
            >
              WhatsApp the Studio
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
