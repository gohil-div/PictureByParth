import { createFileRoute, Link, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/journal")({
  component: JournalLayout,
});

function JournalLayout() {
  return (
    <div className="min-h-screen bg-ivory text-charcoal">
      <header className="absolute left-0 right-0 top-0 z-40">
        <div className="flex items-center justify-between px-6 py-7 md:px-12 md:py-9">
          <Link to="/" className="editorial-eyebrow !text-charcoal hover:!text-gold transition-colors">
            Maison Aurelia
          </Link>
          <nav className="hidden gap-10 text-[0.7rem] uppercase tracking-[0.32em] text-charcoal-soft md:flex">
            <Link to="/journal" className="link-underline hover:text-charcoal">Journal</Link>
            <a href="/journal#chapters" className="link-underline hover:text-charcoal">Chapters</a>
            <a href="/journal#moments" className="link-underline hover:text-charcoal">Moments</a>
            <a href="/journal#contact" className="link-underline hover:text-charcoal">Contact</a>
          </nav>
          <a
            href="/journal#contact"
            className="hidden text-[0.7rem] uppercase tracking-[0.32em] text-charcoal link-underline md:inline-block"
          >
            Enquire
          </a>
        </div>
      </header>

      <Outlet />

      <footer className="border-t border-charcoal/10 px-6 py-16 md:px-12">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-10 md:flex-row md:items-end">
          <div>
            <p className="serif-display text-4xl md:text-5xl">Maison Aurelia</p>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-charcoal-soft">
              An editorial wedding studio publishing intimate stories from
              Tuscany, the Amalfi Coast, the Cotswolds and beyond.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-x-12 gap-y-3 text-[0.7rem] uppercase tracking-[0.32em] text-charcoal-soft md:grid-cols-3">
            <a href="#" className="link-underline hover:text-charcoal">Instagram</a>
            <a href="#" className="link-underline hover:text-charcoal">Pinterest</a>
            <a href="#" className="link-underline hover:text-charcoal">Vimeo</a>
            <a href="#contact" className="link-underline hover:text-charcoal">WhatsApp</a>
            <a href="mailto:studio@maisonaurelia.com" className="link-underline hover:text-charcoal">Email</a>
            <a href="#" className="link-underline hover:text-charcoal">Press</a>
          </div>
        </div>
        <p className="mt-16 text-center text-[0.65rem] uppercase tracking-[0.32em] text-charcoal-soft">
          © {new Date().getFullYear()} Maison Aurelia · Vol. XIV
        </p>
      </footer>
    </div>
  );
}
